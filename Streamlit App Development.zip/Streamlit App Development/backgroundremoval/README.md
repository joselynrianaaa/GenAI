# BackgroundRemoval
Upload an image and adjust the settings to remove the background for any image!

# License
MIT
